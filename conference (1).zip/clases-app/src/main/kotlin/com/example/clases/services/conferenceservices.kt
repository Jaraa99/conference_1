package com.example.clases.services

import com.example.clases.api.repository.conferencerepository
import com.example.clases.model.conference
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class conferenceservices {
    @Autowired
    lateinit var conferenceservices: conferenceservices

    class ClientRepository {
        fun findAll(): List<conference> {

            return TODO("Provide the return value")
        }

        fun save(client: conference): conference {

            return TODO("Provide the return value")
        }

    }

    fun list():List<conference>{
        return conferencerepository.findAll()
    }

    fun save (client: conference): conference{
       return conferencerepository.save(client)
    }
}
