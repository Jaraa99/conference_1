package com.example.clases.api.repository

import com.example.clases.model.conference
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface conference:JpaRepository<conference, Long> {
    fun findById (id: Long?): Module?
}

class conferencerepository {
    companion object {
        fun save(conference: conference): conference {
            TODO("Not yet implemented")
        }

        fun findAll(): List<conference> {
            TODO("Not yet implemented")
        }
    }

}
