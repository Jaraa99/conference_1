package com.example.clases.controller

import com.example.clases.model.conference
import com.example.clases.services.conferenceservices
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/conference")
class conferencecontroller {

    @Autowired
    lateinit var clientservices: conferenceservices

    @GetMapping
    fun list():List<conference>{
        return clientservices.list()

    }
    @PostMapping
    fun save(@RequestBody client: conference): conference{
        return clientservices.save(conference())
    }

    }