CREATE TABLE IF NOT EXISTS conference (
    id SERIAL,
    title VARCHAR(50),
    description VARCHAR(100) NOT NULL,
    CITY VARCHAR(100) NOT NULL,
    total_assistants NUMBER(100),
    PRIMARY KEY (id)
    );
